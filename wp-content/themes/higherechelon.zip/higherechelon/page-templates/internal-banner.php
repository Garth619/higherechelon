	<div class="internal_banner">
		
		<img src="<?php bloginfo('template_directory');?>/images/internal_banner.jpg"/>
		
		<div class="banner_inner">
			
			<span class="banner_header">Helping companies take <strong>organizational performance</strong> to a higher level.</span><!-- banner_header -->
			
		</div><!-- banner_inner -->
		
	</div><!-- internal_banner -->
