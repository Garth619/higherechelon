<?php 
	
	/* Template Name: Home */
	
	get_header();


	get_template_part( 'page-templates/homepage_template_parts/section', '1' );
	get_template_part( 'page-templates/homepage_template_parts/section', '2' );
	get_template_part( 'page-templates/homepage_template_parts/section', '3' );
	get_template_part( 'page-templates/homepage_template_parts/section', '4' );
	
	
	get_footer(); ?>

