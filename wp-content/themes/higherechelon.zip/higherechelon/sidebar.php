<div class="sidebar_wrapper">
	
	<div class="sidebar">
		
		<?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'pa_menu' ) ); ?>
		
		
	</div><!-- sidebar -->
	
</div><!-- sidebar_wrapper -->




